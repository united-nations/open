Legacy UN Transparency Portal: un-system-revenues
Source: https://open.un.org/un-systems-financials/revenue
Captured: 2026-11-18T18:45:21.369154+00:00
Years: 2013–2022
data.json preserves the complete dashboard data payload, including lookup tables, source codes and null values. CSV files provide the same tabular records for convenience; nulls appear as empty CSV fields. No figures have been reconciled or updated. These are data snapshots, not a preservation of the website or its interactive behaviour.
